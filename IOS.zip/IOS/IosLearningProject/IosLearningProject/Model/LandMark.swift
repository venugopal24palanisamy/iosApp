//
//  LandMark.swift
//  IosLearningProject
//
//  Created by Presidio on 06/09/24.
//

import Foundation

struct Landmark: Hashable,Codable,Identifiable{
    var id: Int
    var name : String
}
