//
//  Screen.swift
//  IosLearningProject
//
//  Created by Presidio on 12/09/24.
//

import Foundation
enum Screen {
    case landing
    case login
    case home
}
