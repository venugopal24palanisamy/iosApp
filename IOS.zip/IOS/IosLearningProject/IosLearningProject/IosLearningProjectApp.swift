//
//  IosLearningProjectApp.swift
//  IosLearningProject
//
//  Created by Presidio on 03/09/24.
//

import SwiftUI

@main
struct IosLearningProjectApp: App {
    var body: some Scene {
        WindowGroup {
            AppNavigationView()
        }
    }
}
